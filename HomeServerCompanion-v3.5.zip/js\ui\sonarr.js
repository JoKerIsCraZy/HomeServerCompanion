import * as Sonarr from "../../services/sonarr.js";
import { formatSize } from "../../services/utils.js";
import { showNotification, showConfirmModal } from "../utils.js";

/**
 * Initializes the Sonarr service view.
 * - Fetches and renders Calendar, Queue, and History.
 * - Updates the service badge.
 * @param {string} url - Sonarr URL
 * @param {string} key - API Key
 * @param {object} state - App state
 */
export async function initSonarr(url, key, state) {
    try {
        // Create independent promise chains for parallel execution
        const pCalendar = Sonarr.getSonarrCalendar(url, key)
            .then(calendar => renderSonarrCalendar(calendar, state));

        const pQueue = Sonarr.getSonarrQueue(url, key)
            .then(queue => {
                renderSonarrQueue(queue.records || [], state);
                return updateSonarrBadge(url, key, queue);
            });

        const pHistory = Sonarr.getSonarrHistory(url, key)
            .then(history => renderSonarrHistory(history.records || [], state));

        // Add listeners for new tabs (lazy load)
        const sonarrView = document.getElementById("sonarr-view");
        if (sonarrView) {
            const missingBtn = sonarrView.querySelector('.tab-btn[data-tab="missing"]');
            if (missingBtn) {
                missingBtn.addEventListener('click', () => {
                   loadSonarrMissing(url, key, state);
                });
                
                // If tab is already active (restored state), load immediately
                if (missingBtn.classList.contains('active')) {
                    loadSonarrMissing(url, key, state);
                }
            }
        }

        // Wait for all (settled) so we don't throw on partial failure immediately
        await Promise.allSettled([pCalendar, pQueue, pHistory]);

    } catch (e) {
        console.error("Sonarr loading error", e);
        throw e;
    }
}

function renderSonarrCalendar(episodes, state) {
    const container = document.getElementById("sonarr-calendar");
    if (!container) return;
    container.textContent = "";
    if (episodes.length === 0) {
      const card = document.createElement('div');
      card.className = "card";
      const header = document.createElement('div');
      header.className = "card-header";
      header.textContent = "No upcoming episodes";
      card.appendChild(header);
      container.appendChild(card);
      return;
    }

    // Group by Date
    const grouped = {};
    episodes.forEach((ep) => {
      const dateStr = new Date(ep.airDateUtc).toLocaleDateString();
      if (!grouped[dateStr]) grouped[dateStr] = [];
      grouped[dateStr].push(ep);
    });

    Object.keys(grouped).forEach((dateStr, index) => {
      // Header
      const dateGroup = document.createElement("div");
      dateGroup.className = "date-group";

      // Nice Header Text (Today/Tomorrow checks)
      let headerText = dateStr;
      const dateObj = new Date(grouped[dateStr][0].airDateUtc);
      const today = new Date();
      const tomorrow = new Date();
      tomorrow.setDate(today.getDate() + 1);

      if (dateObj.toDateString() === today.toDateString()) headerText = "Today";
      else if (dateObj.toDateString() === tomorrow.toDateString())
        headerText = "Tomorrow";
      else
        headerText = dateObj.toLocaleDateString(undefined, {
          weekday: "long",
          month: "short",
          day: "numeric",
        });

      const header = document.createElement("div");
      header.className = "date-header";
      header.style.display = "flex";
      header.style.alignItems = "center";
      header.style.justifyContent = "space-between"; // Push link to right
      
      const spanText = document.createElement("span");
      spanText.textContent = headerText;
      header.appendChild(spanText);

      // Add Link to FIRST element ("Top element")
      if (index === 0) {
          const linkBtn = document.createElement('span');
          linkBtn.textContent = "\u2197"; // NE Arrow
          linkBtn.title = "Open Calendar";
          linkBtn.style.cssText = "cursor: pointer; font-size: 1.3em; margin-left: 10px; color: var(--text-secondary); opacity: 0.8; transition: opacity 0.2s;";
          linkBtn.onmouseover = () => linkBtn.style.opacity = "1";
          linkBtn.onmouseout = () => linkBtn.style.opacity = "0.8";
          linkBtn.onclick = (e) => {
              e.stopPropagation();
              let cleanUrl = state.configs.sonarrUrl;
              if(cleanUrl.endsWith('/')) cleanUrl = cleanUrl.slice(0, -1);
              chrome.tabs.create({ url: `${cleanUrl}/calendar` });
          };
          header.appendChild(linkBtn);
      }
      
      dateGroup.appendChild(header);

      // Grid Container
      const grid = document.createElement("div");
      grid.style.cssText = "display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 10px; padding: 5px;";

      // Items
      grouped[dateStr].forEach((ep) => {
        // Find Image (Poster)
        let posterUrl = 'icons/icon48.png';
        if (ep.series && ep.series.images) {
            const posterObj = ep.series.images.find(img => img.coverType.toLowerCase() === 'poster');
            if (posterObj) {
                if (posterObj.url) {
                     // Local URL (needs auth usually)
                     let baseUrl = state.configs.sonarrUrl || "";
                     if(baseUrl.endsWith('/')) baseUrl = baseUrl.slice(0, -1);
                     
                     let imgPath = posterObj.url;
                     if(!imgPath.startsWith('http')) {
                         if (!imgPath.startsWith('/')) imgPath = '/' + imgPath;
                         posterUrl = `${baseUrl}${imgPath}`;
                         
                         const joinChar = posterUrl.includes('?') ? '&' : '?';
                         posterUrl += `${joinChar}apikey=${state.configs.sonarrKey}`;
                     } else {
                         posterUrl = imgPath;
                     }
                } else if (posterObj.remoteUrl) {
                    // Remote URL (direct link to Metadata provider)
                    posterUrl = posterObj.remoteUrl;
                }
            }
        }

        const card = document.createElement("div");
        card.style.cssText = "background: var(--card-bg); border-radius: 8px; overflow: hidden; position: relative; box-shadow: 0 2px 5px rgba(0,0,0,0.2); transition: transform 0.2s;";
        card.onmouseover = () => card.style.transform = "translateY(-2px)";
        card.onmouseout = () => card.style.transform = "translateY(0)";

        const imgDiv = document.createElement("div");
        // Use aspect-ratio to keep poster shape (2:3 is standard)
        imgDiv.style.cssText = "width: 100%; aspect-ratio: 2/3; overflow: hidden;";
        const img = document.createElement("img");
        img.src = posterUrl;
        img.style.cssText = "width: 100%; height: 100%; object-fit: cover;";
        
        // Error Handler
        img.addEventListener('error', () => { 
            if (img.src !== 'icons/icon48.png') img.src = 'icons/icon48.png'; 
        });
        
        imgDiv.appendChild(img);
        
        // Overlay Info
        const infoDiv = document.createElement("div");
        // Stronger gradient for better readability
        infoDiv.style.cssText = "padding: 8px; position: absolute; bottom: 0; width: 100%; background: linear-gradient(to top, rgba(0,0,0,1) 0%, rgba(0,0,0,0.8) 50%, transparent 100%); color: white; text-shadow: 1px 1px 2px black;";
        
        // Series Title
        const sTitle = document.createElement("div");
        sTitle.textContent = ep.series ? ep.series.title : "Unknown";
        sTitle.style.cssText = "font-weight: bold; font-size: 0.9em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;";
        
        // Episode Info
        const epInfo = document.createElement("div");
        const sNum = String(ep.seasonNumber).padStart(2, '0');
        const eNum = String(ep.episodeNumber).padStart(2, '0');
        epInfo.textContent = `S${sNum}E${eNum}`;
        epInfo.style.cssText = "font-size: 0.8em; opacity: 0.9;";
        
        // Time
        const airTime = new Date(ep.airDateUtc);
        const timeStr = airTime.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
        const timeDiv = document.createElement("div");
        timeDiv.textContent = timeStr;
        timeDiv.style.cssText = "font-size: 0.75em; opacity: 0.8; margin-top: 2px;";

        infoDiv.appendChild(sTitle);
        infoDiv.appendChild(epInfo);
        infoDiv.appendChild(timeDiv);

        // Status Ribbon (Top Right)
        let statusColor = "#9e9e9e";
        if (ep.hasFile) statusColor = "#4caf50";
        else if (new Date() > airTime) statusColor = "#f44336"; // Missing
        else statusColor = "#2196f3"; // Airing/Upcoming

        const ribbon = document.createElement("div");
        ribbon.style.cssText = `position: absolute; top: 8px; right: 8px; width: 10px; height: 10px; border-radius: 50%; background: ${statusColor}; box-shadow: 0 0 5px ${statusColor};`;
        ribbon.title = ep.hasFile ? "Downloaded" : (new Date() > airTime ? "Missing" : "Upcoming");

        card.appendChild(imgDiv);
        card.appendChild(infoDiv);
        card.appendChild(ribbon);

        // Click
        if (ep.series && ep.series.titleSlug) {
            card.style.cursor = "pointer";
            card.onclick = () => {
                const url = state.configs.sonarrUrl;
                chrome.tabs.create({ url: `${url}/series/${ep.series.titleSlug}` });
            };
        }

        grid.appendChild(card);
      });

      dateGroup.appendChild(grid);
      container.appendChild(dateGroup);
    });
}

function renderSonarrQueue(records, state) {
    const container = document.getElementById("sonarr-queue");
    if (!container) return;
    container.textContent = "";

    // Helper to refresh queue
    const refreshQueue = async () => {
        const btn = container.querySelector('.refresh-btn');
        if(btn) {
             btn.textContent = "Loading...";
             btn.disabled = true;
        }
        try {
            const newQueue = await Sonarr.getSonarrQueue(state.configs.sonarrUrl, state.configs.sonarrKey);
            await updateSonarrBadge(state.configs.sonarrUrl, state.configs.sonarrKey, newQueue);
            renderSonarrQueue(newQueue.records || [], state);
        } catch(e) {
            if(btn) {
                btn.textContent = "Error";
                setTimeout(() => { 
                    btn.textContent = "↻ Refresh"; 
                    btn.disabled = false; 
                }, 2000);
            }
        }
    };

    // Toolbar
    const toolbar = document.createElement('div');
    toolbar.style.cssText = "display: flex; justify-content: flex-end; margin-bottom: 10px; padding: 0 5px;";
    const refreshBtn = document.createElement('button');
    refreshBtn.className = "refresh-btn";
    refreshBtn.textContent = "↻ Refresh";
    refreshBtn.style.cssText = "background: var(--card-bg); color: var(--text-primary); border: 1px solid var(--border-color); padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 0.9em;";
    refreshBtn.onclick = refreshQueue;
    const linkBtn = document.createElement('button');
    linkBtn.textContent = "\u2197"; // NE Arrow
    linkBtn.title = "Open Activity Queue in Sonarr";
    linkBtn.style.cssText = "background: none; border: none; color: var(--text-secondary); cursor: pointer; font-size: 1.2em; margin-right: 15px; transition: color 0.2s;";
    linkBtn.onmouseover = () => linkBtn.style.color = "var(--primary-color)";
    linkBtn.onmouseout = () => linkBtn.style.color = "var(--text-secondary)";
    linkBtn.onclick = (e) => {
        e.stopPropagation();
        let cleanUrl = state.configs.sonarrUrl;
        if(cleanUrl.endsWith('/')) cleanUrl = cleanUrl.slice(0, -1);
        chrome.tabs.create({ url: `${cleanUrl}/activity/queue` });
    };
    toolbar.appendChild(linkBtn);

    toolbar.appendChild(refreshBtn);
    container.appendChild(toolbar);

    if (records.length === 0) {
      const emptyMsg = document.createElement('div');
      const card = document.createElement('div');
      card.className = "card";
      const header = document.createElement('div');
      header.className = "card-header";
      header.textContent = "Queue Empty";
      card.appendChild(header);
      emptyMsg.appendChild(card);
      container.appendChild(emptyMsg);
      return;
    }

    const tmpl = document.getElementById("sab-queue-item"); // Re-using queue item template
    if (!tmpl) return;

    records.forEach((item) => {
      const clone = tmpl.content.cloneNode(true);
      const itemEl = clone.firstElementChild; // Capture actual element
      itemEl.querySelector(".filename").textContent = item.title;
      
      let percent = 0;
      if (item.size > 0) {
          percent = 100 - (item.sizeleft / item.size) * 100;
      }
      
      itemEl.querySelector(".percentage").textContent = `${Math.round(percent)}%`;
      itemEl.querySelector(".progress-bar-fill").style.width = `${percent}%`;
      itemEl.querySelector(".size").textContent = formatSize(item.sizeleft);
      const statusEl = itemEl.querySelector(".status");
      // Check for warning status
      const tStatus = (item.trackedDownloadStatus || '').toLowerCase();
      let isWarning = false;
      if (tStatus === 'warning' || tStatus === 'error') {
          isWarning = true;
          statusEl.textContent = item.statusMessages && item.statusMessages.length > 0 
              ? item.statusMessages[0].title 
              : "Attention Needed";
          statusEl.style.color = "#ff9800";
          statusEl.style.fontWeight = "bold";
      } else {
          statusEl.textContent = item.status;
      }
      
      // Remove delete button or handle it if Sonarr API supports it easily
      const delBtn = itemEl.querySelector(".delete-btn");
      if(delBtn) {
          // Standard Delete Button Logic (Menu)
          delBtn.style.display = "block";
          delBtn.textContent = "\u00D7"; // Standard X
          
          delBtn.onclick = (e) => {
              e.stopPropagation();
              
              if (delBtn.dataset.confirming === "true") return; 
              
              // Create container for options
              const optionsDiv = document.createElement('div');
              optionsDiv.style.cssText = "display: flex; gap: 5px; margin-left: auto; align-items: center;";
              
              const btnRemove = document.createElement('button');
              btnRemove.textContent = "🗑️";
              btnRemove.title = "Remove from Client";
              btnRemove.style.cssText = "background: #f44336; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer;";
              
              const btnBlock = document.createElement('button');
              btnBlock.textContent = "🚫🔎"; // Block & Search
              btnBlock.title = "Remove, Blocklist & Search";
              btnBlock.style.cssText = "background: #ff9800; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer;";
              
              const cancel = document.createElement('button');
              cancel.textContent = "\u00D7";
              cancel.style.cssText = "background: #9e9e9e; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer;";

              // Actions
              btnRemove.onclick = async (ev) => {
                  ev.stopPropagation();
                  const confirmed = await showConfirmModal(
                      'Remove from Queue',
                      'Remove from queue?',
                      'Remove',
                      '#2196f3' // Sonarr Blue
                  );
                  
                  if(!confirmed) return;

                  try {
                      await Sonarr.deleteQueueItem(state.configs.sonarrUrl, state.configs.sonarrKey, item.id, true, false);
                      delBtn.style.display = 'block';
                      itemEl.remove();
                      optionsDiv.remove();
                      showNotification('Item removed from queue', 'success');
                  } catch(e) { 
                      if (e.message.includes('404')) {
                          showNotification("Item not found (404)", 'error');
                          itemEl.remove();
                      } else {
                          showNotification("Error: " + e.message, 'error'); 
                      }
                  }
                  // Auto-refresh after 3 seconds
                  setTimeout(refreshQueue, 250);
              };

              btnBlock.onclick = async (ev) => {
                  ev.stopPropagation();
                  const confirmed = await showConfirmModal(
                      'Remove & Blocklist',
                      'Remove, Blocklist release and Search for new one?',
                      'Blocklist',
                      '#f44336' // Red for destructive block action
                  );

                  if(!confirmed) return;

                  try {
                    await Sonarr.deleteQueueItem(state.configs.sonarrUrl, state.configs.sonarrKey, item.id, true, true);
                    delBtn.style.display = 'block';
                    optionsDiv.remove();
                    showNotification('Item blocked and searching for new release', 'success');
                  } catch(e) { 
                      if (e.message.includes('404')) {
                          showNotification("Item not found (404)", 'error');
                          itemEl.remove();
                      } else {
                          showNotification("Error: " + e.message, 'error'); 
                      }
                  }
                  // Auto-refresh after 3 seconds
                  setTimeout(refreshQueue, 250);
              };

              cancel.onclick = (ev) => {
                  ev.stopPropagation();
                  delBtn.style.display = 'block';
                  delBtn.style.visibility = 'visible'; // Ensure visible
                  optionsDiv.remove();
              };
              
              optionsDiv.appendChild(btnRemove);
              optionsDiv.appendChild(btnBlock);
              optionsDiv.appendChild(cancel);
              
              delBtn.style.display = "none";
              delBtn.parentNode.insertBefore(optionsDiv, delBtn); // Insert where delBtn was
          };

          // MANUAL IMPORT Button for warnings
          if (isWarning) {
              const importBtn = document.createElement('button');
              importBtn.textContent = "🔧"; // Wrench icon
              importBtn.title = "Manual Import";
              importBtn.style.cssText = "background: none; border: none; color: #ff9800; cursor: pointer; font-size: 16px; margin-right: 8px;";
              importBtn.onclick = (e) => {
                  e.stopPropagation();
                  showManualImportDialog(item, state, itemEl, refreshQueue);
              };
              delBtn.parentNode.insertBefore(importBtn, delBtn);
          }
      }

      container.appendChild(clone);
    });
}

/**
 * Shows a dialog for manual import of a Sonarr queue item
 * @param {Object} item - Queue item with warning/error status
 * @param {Object} state - App state with configs
 * @param {HTMLElement} itemEl - The queue item element
 * @param {Function} refreshQueue - Function to refresh the queue after import
 */
async function showManualImportDialog(item, state, itemEl, refreshQueue) {
    // Remove any existing dialog
    const existingDialog = document.querySelector('.manual-import-dialog');
    if (existingDialog) existingDialog.remove();
    
    // Create dialog container
    const dialog = document.createElement('div');
    dialog.className = 'manual-import-dialog';
    dialog.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.5);
        z-index: 10000;
        min-width: 400px;
        max-width: 90%;
    `;
    
    // Create backdrop
    const backdrop = document.createElement('div');
    backdrop.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.7);
        z-index: 9999;
    `;
    backdrop.onclick = () => {
        dialog.remove();
        backdrop.remove();
    };
    
    // Header
    const header = document.createElement('div');
    header.style.cssText = 'display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;';
    const title = document.createElement('h3');
    title.textContent = 'Manual Import';
    title.style.cssText = 'margin: 0; color: var(--text-primary);';
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.style.cssText = 'background: none; border: none; color: var(--text-secondary); font-size: 24px; cursor: pointer; padding: 0; line-height: 1;';
    closeBtn.onclick = () => {
        dialog.remove();
        backdrop.remove();
    };
    header.appendChild(title);
    header.appendChild(closeBtn);
    dialog.appendChild(header);
    
    // Loading state
    const loadingDiv = document.createElement('div');
    loadingDiv.textContent = 'Loading import options...';
    loadingDiv.style.cssText = 'padding: 20px; text-align: center; color: var(--text-secondary);';
    dialog.appendChild(loadingDiv);
    
    document.body.appendChild(backdrop);
    document.body.appendChild(dialog);
    
    try {
        // Fetch import options AND all available languages/qualities in parallel
        const downloadId = item.downloadId;
        const outputPath = item.outputPath || '';
        
        const [importOptions, allLanguages, allQualities] = await Promise.all([
            Sonarr.getManualImportOptions(
                state.configs.sonarrUrl,
                state.configs.sonarrKey,
                downloadId,
                outputPath
            ),
            Sonarr.getSonarrLanguages(state.configs.sonarrUrl, state.configs.sonarrKey),
            Sonarr.getSonarrQualities(state.configs.sonarrUrl, state.configs.sonarrKey)
        ]);
        
        loadingDiv.remove();
        
        if (!importOptions || importOptions.length === 0) {
            const errorDiv = document.createElement('div');
            errorDiv.textContent = 'No files found for import. The download may have already been imported or removed.';
            errorDiv.style.cssText = 'padding: 20px; color: #ff9800; text-align: center;';
            dialog.appendChild(errorDiv);
            return;
        }
        
        // Use the first file (usually one or more episodes)
        const fileOption = importOptions[0];
        
        // VIDEO FILENAME Display
        const originalNameDiv = document.createElement('div');
        originalNameDiv.style.cssText = 'margin-bottom: 15px;';
        const originalNameLabel = document.createElement('div');
        originalNameLabel.textContent = 'Video File:'; // Changed Label
        originalNameLabel.style.cssText = 'font-weight: bold; color: var(--text-primary); margin-bottom: 5px; font-size: 0.9em;';
        const originalNameValue = document.createElement('div');
        
        // Use relativePath (just the filename usually) or path
        let videoFileName = fileOption.relativePath || fileOption.path || 'Unknown';
        // If it's a full path, try to show just the filename for better readability?
        // Actually user said "Original benennung der nzb file angezeigt werden" initially, 
        // but now "dateinamen der videofile". 
        // Let's show the relative path which is usually "Subtitle.mkv" or "Show.S01E01.mkv".
        
        originalNameValue.textContent = videoFileName; 
        originalNameValue.style.cssText = 'color: var(--text-primary); padding: 8px; background: rgba(0,0,0,0.3); border-radius: 4px; font-family: monospace; font-size: 1.1em; word-break: break-all; line-height: 1.4;';
        originalNameDiv.appendChild(originalNameLabel);
        originalNameDiv.appendChild(originalNameValue);
        dialog.appendChild(originalNameDiv);
        
        // Series/Episode name
        const episodeNameDiv = document.createElement('div');
        episodeNameDiv.style.cssText = 'margin-bottom: 15px;';
        const episodeLabel = document.createElement('div');
        episodeLabel.textContent = 'Episode to Import As:';
        episodeLabel.style.cssText = 'font-weight: bold; color: var(--text-primary); margin-bottom: 5px; font-size: 0.9em;';
        const episodeValue = document.createElement('div');
        
        let episodeText = 'Unknown';
        if (fileOption.series && fileOption.episodes && fileOption.episodes.length > 0) {
            const ep = fileOption.episodes[0];
            const sNum = String(ep.seasonNumber || 0).padStart(2, '0');
            const eNum = String(ep.episodeNumber || 0).padStart(2, '0');
            episodeText = `${fileOption.series.title} - S${sNum}E${eNum} - ${ep.title || ''}`;
        }
        
        episodeValue.textContent = episodeText;
        episodeValue.style.cssText = 'color: var(--text-secondary); padding: 8px; background: var(--bg-secondary); border-radius: 4px; border: 1px solid var(--border-color);';
        episodeNameDiv.appendChild(episodeLabel);
        episodeNameDiv.appendChild(episodeValue);
        dialog.appendChild(episodeNameDiv);
        
        // Quality dropdown
        const qualityDiv = document.createElement('div');
        qualityDiv.style.cssText = 'margin-bottom: 15px;';
        const qualityLabel = document.createElement('label');
        qualityLabel.textContent = 'Quality:';
        qualityLabel.style.cssText = 'font-weight: bold; color: var(--text-primary); display: block; margin-bottom: 5px; font-size: 0.9em;';
        const qualitySelect = document.createElement('select');
        // Force dark background and light text for visibility
        qualitySelect.style.cssText = 'width: 100%; padding: 8px; background-color: #2b2b2b; color: #eeeeee; border: 1px solid var(--border-color); border-radius: 4px; cursor: pointer;';
        
        // Populate ALL valid qualities
        // Current quality from file detection
        // Populate ALL valid qualities
        // Current quality from file detection
        const detectedQualityId = fileOption.quality?.quality?.id;
        const detectedQualityName = fileOption.quality?.quality?.name; // e.g. "WEBDL-1080p"
        
        // Find the BEST matching quality definition
        // 1. Try matching by Name (most accurate visually)
        // 2. Fallback to ID match
        let targetQuality = allQualities.find(q => detectedQualityName && (q.title === detectedQualityName || q.name === detectedQualityName));
        if (!targetQuality) {
            targetQuality = allQualities.find(q => q.id == detectedQualityId);
        }
        


        allQualities.sort((a,b) => a.title.localeCompare(b.title)).forEach(qDef => {
             const option = document.createElement('option');
             
             const qualityObj = {
                 quality: { id: qDef.id, name: qDef.name },
                 revision: fileOption.quality?.revision || { version: 1, real: 0, isRepack: false }
             };

             option.value = JSON.stringify(qualityObj);
             option.textContent = qDef.title;
             option.style.backgroundColor = "#2b2b2b";
             option.style.color = "#eeeeee";
             
             // Select if it matches our determined target
             if (targetQuality && qDef.id === targetQuality.id) {
                 option.selected = true;
             }
             qualitySelect.appendChild(option);
        });
        
        // (Removed old fallback check)

        // Add rejections as info
        if (fileOption.rejections && fileOption.rejections.length > 0) {
            const rejectionsDiv = document.createElement('div');
            rejectionsDiv.style.cssText = 'font-size: 0.85em; color: #ff9800; margin-top: 5px;';
            rejectionsDiv.textContent = 'Issues: ' + fileOption.rejections.map(r => r.reason).join(', ');
            qualityDiv.appendChild(rejectionsDiv);
        }
        
        qualityDiv.appendChild(qualityLabel);
        qualityDiv.appendChild(qualitySelect);
        dialog.appendChild(qualityDiv);
        
        // Language dropdown
        const languageDiv = document.createElement('div');
        languageDiv.style.cssText = 'margin-bottom: 20px;';
        const languageLabel = document.createElement('label');
        languageLabel.textContent = 'Language:';
        languageLabel.style.cssText = 'font-weight: bold; color: var(--text-primary); display: block; margin-bottom: 5px; font-size: 0.9em;';
        const languageSelect = document.createElement('select');
        // Force dark background and light text here too
        languageSelect.style.cssText = 'width: 100%; padding: 8px; background-color: #2b2b2b; color: #eeeeee; border: 1px solid var(--border-color); border-radius: 4px; cursor: pointer;';
        
        // Populate ALL languages
        // Current language from file detection
        // fileOption.languages is an array, usually has 1 main language
        const detectedLangId = (fileOption.languages && fileOption.languages.length > 0) ? fileOption.languages[0].id : null;

        allLanguages.sort((a,b) => a.name.localeCompare(b.name)).forEach(lang => {
            const option = document.createElement('option');
            option.value = JSON.stringify(lang);
            option.textContent = lang.name;
            option.style.backgroundColor = "#2b2b2b";
            option.style.color = "#eeeeee";
            
            if (lang.id === detectedLangId) {
                option.selected = true;
            } else if (!detectedLangId && lang.name === "English") {
                // Default to english if nothing detected?
                // option.selected = true; 
            }
            languageSelect.appendChild(option);
        });
        
        languageDiv.appendChild(languageLabel);
        languageDiv.appendChild(languageSelect);
        dialog.appendChild(languageDiv);
        
        // Buttons
        const buttonsDiv = document.createElement('div');
        buttonsDiv.style.cssText = 'display: flex; gap: 10px; justify-content: flex-end;';
        
        const cancelBtn = document.createElement('button');
        cancelBtn.textContent = 'Cancel';
        cancelBtn.style.cssText = 'padding: 8px 16px; background: var(--bg-secondary); color: var(--text-primary); border: 1px solid var(--border-color); border-radius: 4px; cursor: pointer;';
        cancelBtn.onclick = () => {
            dialog.remove();
            backdrop.remove();
        };
        
        const importBtn = document.createElement('button');
        importBtn.textContent = 'Import';
        importBtn.style.cssText = 'padding: 8px 16px; background: #4caf50; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;';
        importBtn.onclick = async () => {
            importBtn.disabled = true;
            importBtn.textContent = 'Importing...';
            
            try {
                const selectedQuality = JSON.parse(qualitySelect.value);
                const selectedLanguage = JSON.parse(languageSelect.value);
                
                // Prepare import file
                const importFile = {
                    path: fileOption.path,
                    seriesId: fileOption.series?.id || item.seriesId,
                    episodeIds: fileOption.episodes?.map(ep => ep.id) || [],
                    quality: selectedQuality,
                    languages: [selectedLanguage],
                    releaseGroup: fileOption.releaseGroup || ''
                };
                
                // Execute import
                await Sonarr.executeManualImport(
                    state.configs.sonarrUrl,
                    state.configs.sonarrKey,
                    [importFile]
                );
                
                // Close dialog
                dialog.remove();
                backdrop.remove();
                
                // Refresh queue after a short delay
                setTimeout(refreshQueue, 1000);
                
            } catch (error) {
                importBtn.disabled = false;
                importBtn.textContent = 'Import';
                alert('Import failed: ' + error.message);
            }
        };
        
        buttonsDiv.appendChild(cancelBtn);
        buttonsDiv.appendChild(importBtn);
        dialog.appendChild(buttonsDiv);
        
    } catch (error) {
        loadingDiv.textContent = 'Error loading import options: ' + error.message;
        loadingDiv.style.color = '#f44336';
    }
}



function renderSonarrHistory(records, state) {
    const container = document.getElementById("sonarr-history");
    if (!container) return;
    container.textContent = "";

    // Filter for only 'downloadFolderImported'
    // We fetch more initially to allow for grouping compression
    const rawFiltered = records
      .filter((r) => r.eventType === "downloadFolderImported")
      .slice(0, 100);

    if (rawFiltered.length === 0) {
      const card = document.createElement('div');
      card.className = "card";
      const header = document.createElement('div');
      header.className = "card-header";
      header.textContent = "No recent downloads";
      card.appendChild(header);
      container.appendChild(card);
      return;
    }

    // Grouping Logic
    const groupedItems = [];
    if (rawFiltered.length > 0) {
        let currentGroup = [rawFiltered[0]];
        
        for (let i = 1; i < rawFiltered.length; i++) {
            const prev = currentGroup[0];
            const curr = rawFiltered[i];
            
            // Check if same series (by titleSlug or id)
            // And also check if same season? Usually safer to group by season too, 
            // otherwise S01E24 and S02E01 might look weird as S01E24-01 without season handling.
            // Let's assume strict grouping: Same Series AND Same Season.
            const sameSeries = (prev.series && curr.series && prev.series.id === curr.series.id);
            const prevSeason = prev.episode ? prev.episode.seasonNumber : -1;
            const currSeason = curr.episode ? curr.episode.seasonNumber : -2;
            
            if (sameSeries && prevSeason === currSeason) {
                currentGroup.push(curr);
            } else {
                groupedItems.push(currentGroup);
                currentGroup = [curr];
            }
        }
        groupedItems.push(currentGroup);
    }
    
    // Limit to 10 visible Cards (groups)
    const displayGroups = groupedItems.slice(0, 10);

    // Grid Container for History
    const grid = document.createElement("div");
    grid.style.cssText = "display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 15px;";

    displayGroups.forEach((group) => {
      // Use the first item for Series Info / Images
      const mainItem = group[0];
      const series = mainItem.series || {};
      const date = new Date(mainItem.date).toLocaleDateString();
      
      // Determine Episode Label
      let epString = "";
      let epTitleString = "";
      
      if (group.length === 1) {
          // Single Episode
          const ep = mainItem.episode || {};
          const sNum = String(ep.seasonNumber || 0).padStart(2, '0');
          const eNum = String(ep.episodeNumber || 0).padStart(2, '0');
          epString = `S${sNum}E${eNum}`;
          epTitleString = ep.title || "";
      } else {
          // Multi Episode Group
          // Find Min/Max Episode Numbers
          const epNumbers = group.map(i => i.episode ? i.episode.episodeNumber : 0).sort((a,b) => a-b);
          const minEp = epNumbers[0];
          const maxEp = epNumbers[epNumbers.length - 1];
          const count = group.length;
          
          const sNum = String(mainItem.episode.seasonNumber || 0).padStart(2, '0');
          // e.g. S12E10-14
          // Note: Logic assumes continuous range, but even if S12E10 and S12E12 (gap), showing E10-12 might be acceptable or specific list "E10, E12".
          // User requested "S12E10-14". Let's stick to Range if > 2, or Comma if 2? 
          // Re-reading: "S12E10-14 z.B." (Range).
          
          // Check if contiguous? 
          // Ideally yes, but "imported" events usually happen in batches.
          
          epString = `S${sNum}E${minEp}-${maxEp}`;
          
          // For title, "3 Episodes" or join titles?
          if (count <= 2) {
              epTitleString = group.map(i => i.episode.title).join(" / ");
          } else {
              epTitleString = `${count} Episodes Imported`;
          }
      }

      // 2. Images (Poster & Banner)
      let posterUrl = 'icons/icon48.png';
      let bannerUrl = '';
      
      if (series.images) {
          // Find Poster
          const posterObj = series.images.find(img => img.coverType.toLowerCase() === 'poster');
          if(posterObj) {
               if(posterObj.url) {
                    let baseUrl = state.configs.sonarrUrl || "";
                    if(baseUrl.endsWith('/')) baseUrl = baseUrl.slice(0, -1);
                    if(!posterObj.url.startsWith('http')) { 
                        posterUrl = `${baseUrl}${posterObj.url.startsWith('/') ? '' : '/'}${posterObj.url}?apikey=${state.configs.sonarrKey}`; 
                    } else { posterUrl = posterObj.url; }
               } else if (posterObj.remoteUrl) { posterUrl = posterObj.remoteUrl; }
          }
          
          // Find Banner (or Fanart as fallback)
          const bannerObj = series.images.find(img => img.coverType.toLowerCase() === 'banner') 
                         || series.images.find(img => img.coverType.toLowerCase() === 'fanart');
          if(bannerObj) {
              if(bannerObj.url) {
                    let baseUrl = state.configs.sonarrUrl || "";
                    if(baseUrl.endsWith('/')) baseUrl = baseUrl.slice(0, -1);
                    if(!bannerObj.url.startsWith('http')) { 
                        bannerUrl = `${baseUrl}${bannerObj.url.startsWith('/') ? '' : '/'}${bannerObj.url}?apikey=${state.configs.sonarrKey}`; 
                    } else { bannerUrl = bannerObj.url; }
               } else if (bannerObj.remoteUrl) { bannerUrl = bannerObj.remoteUrl; }
          }
      }

      // 3. Card DOM
      const card = document.createElement("div");
      card.className = "history-card";
      card.style.cssText = `
        position: relative; 
        border-radius: 12px; 
        overflow: hidden; 
        height: 140px; 
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
        background: var(--card-bg);
        transition: transform 0.2s;
        cursor: pointer;
      `;
      // Click to Series
      if (series.titleSlug) {
          card.onclick = () => {
              const url = state.configs.sonarrUrl;
              chrome.tabs.create({ url: `${url}/series/${series.titleSlug}` });
          };
          card.onmouseenter = () => card.style.transform = "translateY(-3px)";
          card.onmouseleave = () => card.style.transform = "translateY(0)";
      }

      // 3a. Background (Banner)
      const bg = document.createElement("div");
      bg.style.cssText = `
          position: absolute; top:0; left:0; width:100%; height:100%;
          background-image: url('${bannerUrl || posterUrl}'); 
          background-size: cover; 
          background-position: center;
          opacity: 0.2; 
          filter: blur(2px) grayscale(40%);
          z-index: 0;
          transition: opacity 0.3s;
      `;
      card.appendChild(bg);

      // Hover effect
      card.addEventListener('mouseenter', () => { bg.style.opacity = '0.3'; bg.style.filter = 'blur(1px) grayscale(0%)'; });
      card.addEventListener('mouseleave', () => { bg.style.opacity = '0.2'; bg.style.filter = 'blur(2px) grayscale(40%)'; });

      // 3b. Content Layout
      const content = document.createElement("div");
      content.style.cssText = `
          position: relative; z-index: 1;
          display: flex; height: 100%;
          padding: 10px;
          gap: 15px;
          align-items: center;
      `;
      
      // Poster
      const posterImg = document.createElement("img");
      posterImg.src = posterUrl;
      posterImg.style.cssText = "height: 100%; aspect-ratio: 2/3; object-fit: cover; border-radius: 6px; box-shadow: 2px 2px 5px rgba(0,0,0,0.5);";
      posterImg.onerror = () => { posterImg.src = 'icons/icon48.png'; };
      
      // Info
      const info = document.createElement("div");
      info.style.cssText = "flex: 1; min-width: 0; display: flex; flex-direction: column; justify-content: center;";
      
      const titleEl = document.createElement("div");
      titleEl.textContent = series.title || "Unknown Series";
      titleEl.title = series.title;
      titleEl.style.cssText = "font-weight: 800; font-size: 1.1em; margin-bottom: 4px; color: var(--text-primary); text-shadow: 0 2px 4px rgba(0,0,0,0.8); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;";
      
      const epEl = document.createElement("div");
      epEl.textContent = epString;
      epEl.style.cssText = "font-weight: 700; color: var(--accent-sonarr); font-size: 1em; margin-bottom: 2px; text-shadow: 0 1px 2px rgba(0,0,0,0.8);";
      
      const epTitleEl = document.createElement("div");
      epTitleEl.textContent = epTitleString;
      epTitleEl.style.cssText = "font-size: 0.85em; color: var(--text-secondary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 100%; opacity: 0.9;";
      
      const metaEl = document.createElement("div");
      const quality = mainItem.quality && mainItem.quality.quality ? mainItem.quality.quality.name : "";
      metaEl.textContent = `${quality} • ${date}`;
      metaEl.style.cssText = "font-size: 0.75em; color: #e0e0e0; margin-top: 5px; opacity: 0.9;";

      info.appendChild(titleEl);
      info.appendChild(epEl);
      info.appendChild(epTitleEl);
      info.appendChild(metaEl);

      content.appendChild(posterImg);
      content.appendChild(info);
      card.appendChild(content);
      
      grid.appendChild(card);
    });

    container.appendChild(grid);
}

async function updateSonarrBadge(url, key, existingQueue = null) {
    const sonarrNavItem = document.querySelector('.nav-item[data-target="sonarr"]');
    if (!sonarrNavItem) return;

    let badge = sonarrNavItem.querySelector('.nav-badge');
    if (!badge) {
        badge = document.createElement('div');
        badge.className = 'nav-badge hidden';
        sonarrNavItem.appendChild(badge);
    }
    
    try {
        const queue = existingQueue || await Sonarr.getSonarrQueue(url, key);
        const records = queue.records || [];
        
        const issues = records.filter(item => {
            const tStatus = (item.trackedDownloadStatus || '').toLowerCase();
            const status = (item.status || '').toLowerCase();
            return tStatus === 'warning' || tStatus === 'error' || status === 'failed';
        });

        const count = issues.length;
        
        // Update navigation badge
        if (count > 0) {
            badge.textContent = count;
            badge.classList.remove('hidden');
        } else {
            badge.classList.add('hidden');
        }
        
        // Update Queue tab badge
        const sonarrView = document.getElementById('sonarr-view');
        if (sonarrView) {
            const queueTabBtn = sonarrView.querySelector('.tab-btn[data-tab="queue"]');
            if (queueTabBtn) {
                let tabBadge = queueTabBtn.querySelector('.tab-badge');
                if (!tabBadge) {
                    tabBadge = document.createElement('span');
                    tabBadge.className = 'tab-badge hidden';
                    queueTabBtn.appendChild(tabBadge);
                }
                
                if (count > 0) {
                    tabBadge.textContent = count;
                    tabBadge.classList.remove('hidden');
                } else {
                    tabBadge.classList.add('hidden');
                }
            }
        }
    } catch (e) {
        console.error("Sonarr badge update error", e);
        badge.classList.add('hidden');
    }
}

/**
 * Loads missing episodes
 */
/**
 * Loads missing episodes with Caching (15 min)
 */
async function loadSonarrMissing(url, key, state, forceRefresh = false) {
    const container = document.getElementById("sonarr-missing");
    if (!container) return;
    
    // Check Cache first
    if (!forceRefresh) {
        try {
            const cache = await new Promise(resolve => chrome.storage.local.get(['sonarrMissingCache'], resolve));
            if (cache.sonarrMissingCache) {
                const { timestamp, data } = cache.sonarrMissingCache;
                const age = (Date.now() - timestamp) / 1000 / 60; // Minutes
                if (age < 15) {
                    renderSonarrMissing(data, state);
                    return; 
                }
            }
        } catch(e) { console.warn("Cache read error", e); }
    }

    container.textContent = '';
    const spinner = document.createElement('div');
    spinner.className = 'loading-spinner';
    spinner.textContent = 'Loading Missing Episodes...';
    container.appendChild(spinner);
    
    try {
        const data = await Sonarr.getSonarrMissing(url, key);
        const records = data.records || [];
        
        renderSonarrMissing(records, state);
        
        // Save Cache
        chrome.storage.local.set({
            sonarrMissingCache: {
                timestamp: Date.now(),
                data: records
            }
        });
        
    } catch (e) {
        container.textContent = '';
        const errBanner = document.createElement('div');
        errBanner.className = 'error-banner';
        errBanner.textContent = 'Error loading missing: ' + e.message;
        container.appendChild(errBanner);
    }
}

/**
 * Renders missing episodes as a Poster Grid (similar to Calendar/Recent)
 * Filters for Released episodes only.
 */
function renderSonarrMissing(records, state) {
    const container = document.getElementById("sonarr-missing");
    if (!container) return;
    container.textContent = '';
    
    // Filter: AirDate must be in the past (Released)
    const now = new Date();
    const filtered = records.filter(item => {
        if (!item.airDateUtc) return false;
        return new Date(item.airDateUtc) <= now;
    });

    // Sort by Date Descending
    // Sort by Date Descending
    filtered.sort((a, b) => new Date(b.airDateUtc) - new Date(a.airDateUtc));

    // Toolbar / Header
    const toolbar = document.createElement('div');
    toolbar.style.cssText = "display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; padding: 0 5px;";
    
    const countBadge = document.createElement('div');
    countBadge.textContent = `${filtered.length} Missing`;
    countBadge.style.cssText = "font-weight: bold; color: var(--text-secondary); font-size: 0.9em;";
    
    const refreshBtn = document.createElement('button');
    refreshBtn.textContent = "↻ Refresh Cache";
    refreshBtn.style.cssText = "background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.1); color: var(--text-primary); padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 0.85em; transition: all 0.2s;";
    refreshBtn.onmouseover = () => refreshBtn.style.background = "rgba(255,255,255,0.2)";
    refreshBtn.onmouseout = () => refreshBtn.style.background = "rgba(255,255,255,0.1)";
    refreshBtn.onclick = () => {
        loadSonarrMissing(state.configs.sonarrUrl, state.configs.sonarrKey, state, true);
    };
    
    toolbar.appendChild(countBadge);
    toolbar.appendChild(refreshBtn);
    container.appendChild(toolbar);

    if (filtered.length === 0) {
        const emptyMsg = document.createElement('div');
        emptyMsg.className = "card";
        emptyMsg.style.padding = "20px";
        emptyMsg.style.textAlign = "center";
        emptyMsg.style.color = "var(--text-secondary)";
        emptyMsg.textContent = "No missing released episodes found.";
        container.appendChild(emptyMsg);
        return;
    }

    const grid = document.createElement("div");
    grid.style.cssText = "display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 10px; padding: 5px;";

    filtered.forEach(item => {
        const card = document.createElement("div");
        card.style.cssText = "background: var(--card-bg); border-radius: 8px; overflow: hidden; position: relative; box-shadow: 0 2px 5px rgba(0,0,0,0.2); transition: transform 0.2s; cursor: pointer;";
        
        // Find Image (Poster)
        let posterUrl = 'icons/icon48.png';
        if (item.series && item.series.images) {
            const posterObj = item.series.images.find(img => img.coverType.toLowerCase() === 'poster');
            if (posterObj) {
                if (posterObj.url) {
                     let baseUrl = state.configs.sonarrUrl || "";
                     if(baseUrl.endsWith('/')) baseUrl = baseUrl.slice(0, -1);
                     
                     let imgPath = posterObj.url;
                     if(!imgPath.startsWith('http')) {
                         if (!imgPath.startsWith('/')) imgPath = '/' + imgPath;
                         posterUrl = `${baseUrl}${imgPath}`;
                         const joinChar = posterUrl.includes('?') ? '&' : '?';
                         posterUrl += `${joinChar}apikey=${state.configs.sonarrKey}`;
                     } else {
                         posterUrl = imgPath;
                     }
                } else if (posterObj.remoteUrl) {
                    posterUrl = posterObj.remoteUrl;
                }
            }
        }

        const imgDiv = document.createElement("div");
        imgDiv.style.cssText = "width: 100%; aspect-ratio: 2/3; overflow: hidden;";
        const img = document.createElement("img");
        img.src = posterUrl;
        img.style.cssText = "width: 100%; height: 100%; object-fit: cover;";
        img.onerror = () => { if (img.src !== 'icons/icon48.png') img.src = 'icons/icon48.png'; };
        imgDiv.appendChild(img);
        
        // Overlay Info
        const infoDiv = document.createElement("div");
        infoDiv.style.cssText = "padding: 8px; position: absolute; bottom: 0; width: 100%; background: linear-gradient(to top, rgba(0,0,0,1) 0%, rgba(0,0,0,0.8) 50%, transparent 100%); color: white; text-shadow: 1px 1px 2px black;";
        
        const sTitle = document.createElement("div");
        sTitle.textContent = item.series ? item.series.title : "Unknown";
        sTitle.style.cssText = "font-weight: bold; font-size: 0.9em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;";
        
        const epInfo = document.createElement("div");
        const sNum = String(item.seasonNumber).padStart(2, '0');
        const eNum = String(item.episodeNumber).padStart(2, '0');
        epInfo.textContent = `S${sNum}E${eNum}`;
        epInfo.style.cssText = "font-size: 0.8em; opacity: 0.9;";
        
        const airDate = new Date(item.airDateUtc).toLocaleDateString();
        const dateDiv = document.createElement("div");
        dateDiv.textContent = airDate;
        dateDiv.style.cssText = "font-size: 0.75em; opacity: 0.8; margin-top: 2px;";

        infoDiv.appendChild(sTitle);
        infoDiv.appendChild(epInfo);
        infoDiv.appendChild(dateDiv);

        // Search Button (overlay on hover or persistent small icon)
        // User requested "Design from Calendar", calendar has click to open. 
        // We add a search icon at top right.
        const searchBtn = document.createElement("div");
        searchBtn.textContent = "🔍";
        searchBtn.title = "Search for Episode";
        searchBtn.style.cssText = `
            position: absolute; top: 5px; right: 5px; 
            width: 24px; height: 24px; 
            background: rgba(0,0,0,0.6); border-radius: 50%; 
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; font-size: 14px; color: white;
            border: 1px solid rgba(255,255,255,0.3);
            transition: background 0.2s;
        `;
        searchBtn.onmouseover = () => searchBtn.style.background = "#2196f3";
        searchBtn.onmouseout = () => searchBtn.style.background = "rgba(0,0,0,0.6)";
        
        searchBtn.onclick = async (e) => {
             e.stopPropagation();
             searchBtn.style.pointerEvents = "none";
             searchBtn.textContent = "⏳";
             try {
                 await fetch(`${state.configs.sonarrUrl}/api/v3/command`, {
                     method: 'POST',
                     headers: { 
                        'X-Api-Key': state.configs.sonarrKey,
                        'Content-Type': 'application/json'
                     },
                     body: JSON.stringify({
                         name: 'EpisodeSearch',
                         episodeIds: [item.id]
                     })
                 });
                 showNotification('Search started', 'success');
                 searchBtn.textContent = "✓";
             } catch(err) {
                 showNotification('Search failed', 'error');
                 searchBtn.textContent = "❌";
             }
        };

        card.appendChild(imgDiv);
        card.appendChild(infoDiv);
        card.appendChild(searchBtn);

        // Card Click -> Open Series
        card.onclick = () => {
             if (item.series && item.series.titleSlug) {
                 const url = state.configs.sonarrUrl;
                 chrome.tabs.create({ url: `${url}/series/${item.series.titleSlug}` });
             }
        };

        grid.appendChild(card);
    });
    
    container.appendChild(grid);
}

// Export for background updates
export { updateSonarrBadge };
