import * as Overseerr from "../../services/overseerr.js";
import { showNotification, showConfirmModal } from "../utils.js";

/**
 * Initializes the Overseerr service view.
 * - Handles Trending, Requests, and Search tabs.
 * - Sets up filtering and auto-reload logic.
 * @param {string} url - Overseerr URL
 * @param {string} key - API Key
 * @param {object} state - App state
 */
export async function initOverseerr(url, key, state) {
    if (!url || !key) {
        const container = document.getElementById('overseerr-requests');
        if(container) {
            container.textContent = "";
            const div = document.createElement('div');
            div.className = 'error-banner';
            div.textContent = "Please configure Overseerr in options.";
            container.appendChild(div);
        }
        return;
    }
    
    // Setup Filter Listener (Ensure single binding)
    const filterSelect = document.getElementById('overseerr-filter');
    
    if (filterSelect) {
        if (state.configs.overseerrFilter) {
            filterSelect.value = state.configs.overseerrFilter;
        }
    }

    if (filterSelect && !filterSelect.dataset.listenerAttached) {
        filterSelect.addEventListener('change', () => {
             // Save preference
             const newVal = filterSelect.value;
             state.configs.overseerrFilter = newVal; // Update local state
             chrome.storage.sync.set({ overseerrFilter: newVal });

             loadRequests(url, key, filterSelect.value);
        });
        filterSelect.dataset.listenerAttached = "true";
    }

    // Setup Trending Filter Listener
    const trendingFilterSelect = document.getElementById('overseerr-trending-filter');
    if (trendingFilterSelect) {
        // Load saved preference
        if (state.configs.overseerrTrendingFilter) {
            trendingFilterSelect.value = state.configs.overseerrTrendingFilter;
        }
    }

    if (trendingFilterSelect && !trendingFilterSelect.dataset.listenerAttached) {
        trendingFilterSelect.addEventListener('change', () => {
            const newVal = trendingFilterSelect.value;
            state.configs.overseerrTrendingFilter = newVal;
            chrome.storage.sync.set({ overseerrTrendingFilter: newVal });
            // Reload trending with new filter (keep same pages)
            loadTrending(url, key, newVal);
        });
        trendingFilterSelect.dataset.listenerAttached = "true";
    }

    // Setup Tab Listeners for auto-reload
    const trendingBtn = document.querySelector('.sub-tab-btn[data-target="overseerr-trending-tab"]');
    if (trendingBtn && !trendingBtn.dataset.listenerAttached) {
         trendingBtn.addEventListener('click', () => {
             // Reload trending with new random pages
             const trendingFilter = document.getElementById('overseerr-trending-filter')?.value || 'both';
             loadTrending(url, key, trendingFilter);
         });
         trendingBtn.dataset.listenerAttached = "true";
    }

    // Initial Load
    const currentFilter = filterSelect ? filterSelect.value : (state.configs.overseerrFilter || 'pending');
    // 5. Check active tab and load content
    const trendingTab = document.getElementById('overseerr-trending-tab');
    const searchTab = document.getElementById('overseerr-search-tab');

    // If Trending is visible, load trending
    if (trendingTab && !trendingTab.classList.contains('hidden')) {
        const trendingFilter = document.getElementById('overseerr-trending-filter')?.value || 'both';
        await loadTrending(url, key, trendingFilter);
    } 
    // If Search is visible, do nothing (wait for user search?)
    else if (searchTab && !searchTab.classList.contains('hidden')) {
        // Maybe focus input?
    }
    // Otherwise (Requests tab is default), load requests
    else {
        // Only load if container exists
        if (document.getElementById('overseerr-requests')) {
            await loadRequests(url, key, currentFilter);
        }
    }
}

export async function loadTrending(url, key, typeFilter = 'both') {
    const container = document.getElementById('overseerr-trending-results');
    if (!container) return;
    
    container.textContent = "";
    const loadDiv = document.createElement('div');
    loadDiv.className = "loading";
    loadDiv.textContent = "Loading Trending...";
    container.appendChild(loadDiv);

    try {
        // Fetch multiple pages to ensure we have enough items after filtering
        // RANDOMIZE: Start page between 1 and 10 to show "new" stuff each time
        const startPage = Math.floor(Math.random() * 10) + 1;
        
        const promises = [
            Overseerr.getTrending(url, key, startPage),
            Overseerr.getTrending(url, key, startPage + 1),
            Overseerr.getTrending(url, key, startPage + 2)
        ];
        
        const resultsArrays = await Promise.all(promises);
        
        // Flatten and deduplicate by ID
        const allResults = resultsArrays.flat();
        const seen = new Set();
        const uniqueResults = [];
        
        for (const item of allResults) {
            if (!seen.has(item.id)) {
                seen.add(item.id);
                uniqueResults.push(item);
            }
        }

        renderTrendingTab(uniqueResults, url, key, typeFilter);
    } catch (e) {
        console.error(e);
        container.replaceChildren();
        const err = document.createElement('div');
        err.className = 'error-banner';
        err.textContent = `Failed to load trending: ${e.message}`;
        container.appendChild(err);
    }
}

function renderTrendingTab(results, url, key, typeFilter = 'both') {
    const container = document.getElementById('overseerr-trending-results');
    if (!container) return;
    container.replaceChildren();
    // Use grid-container to layout cards properly similar to Requests
    container.className = 'grid-container'; 
    container.style = ''; // Clear inline styles
    container.style.gridTemplateColumns = 'repeat(3, 1fr)'; // Force 3 columns as requested


    if (results.length === 0) {
        const card = document.createElement('div');
        card.className = "card";
        const header = document.createElement('div');
        header.className = "card-header";
        header.textContent = "No trending items found";
        card.appendChild(header);
        container.appendChild(card);
        return;
    }

    const tmpl = document.getElementById('overseerr-trending-card');

    // Filter by type first (movie/tv/both)
    let typeFilteredResults = results;
    if (typeFilter === 'movie') {
        typeFilteredResults = results.filter(item => {
            const rawMediaType = item.mediaType || item.media_type;
            return rawMediaType === 'movie';
        });
    } else if (typeFilter === 'tv') {
        typeFilteredResults = results.filter(item => {
            const rawMediaType = item.mediaType || item.media_type;
            return rawMediaType === 'tv';
        });
    }

    // Filter out already requested/available items
    const filteredResults = typeFilteredResults.filter(item => {
        if (!item.mediaInfo) return true; 
        const s = item.mediaInfo.status;
        if (s === 2 || s === 3 || s === 4 || s === 5) return false;
        return true;
    });

    if (filteredResults.length === 0) {
        const card = document.createElement('div');
        card.className = "card";
        const header = document.createElement('div');
        header.className = "card-header";
        header.textContent = "All trending items already requested!";
        card.appendChild(header);
        container.appendChild(card);
        return;
    }

    filteredResults.forEach(item => {
        const clone = tmpl.content.cloneNode(true);
        
        // Image
        const posterImg = clone.querySelector('.poster-img');
        const posterPath = item.posterPath;
        if (posterPath) {
           const posterUrl = `https://image.tmdb.org/t/p/w200${posterPath}`;
           posterImg.src = posterUrl;
        } else {
           posterImg.src = 'icons/icon48.png';
        }

        // Backdrop
        const backdropDiv = clone.querySelector('.overseerr-backdrop');
        if (backdropDiv && item.backdropPath) {
             const backdropUrl = `https://image.tmdb.org/t/p/w500${item.backdropPath}`;
             backdropDiv.style.backgroundImage = `url('${backdropUrl}')`;
        }


        // Title
        const title = item.title || item.name || 'Unknown';
        const titleEl = clone.querySelector('.media-title');
        titleEl.textContent = title;
        titleEl.title = title;

        // Meta Info
        const year = item.releaseDate ? item.releaseDate.split('-')[0] : (item.firstAirDate ? item.firstAirDate.split('-')[0] : 'Unknown');
        const rating = item.voteAverage ? `★ ${item.voteAverage.toFixed(1)}` : '';
        
        clone.querySelector('.media-year').textContent = year;
        clone.querySelector('.media-rating').textContent = rating;


        // Media Type Badge
        const rawMediaType = item.mediaType || item.media_type;
        const mediaType = rawMediaType === 'tv' ? 'tv' : 'movie'; 
        
        if (rawMediaType === 'person') return;

        const badge = clone.querySelector('.media-type-badge');
        if (badge) {
            badge.textContent = mediaType === 'tv' ? 'SERIES' : 'MOVIE';
            badge.style.background = mediaType === 'tv' ? '#2196f3' : '#ff9800';
            badge.style.color = '#fff'; // White text for both
        }

        // Clickable Poster/Title -> Open in Overseerr
        const openInOverseerr = () => {
             const targetUrl = `${url}/${mediaType}/${item.id}`;
             chrome.tabs.create({ url: targetUrl });
        };
        posterImg.style.cursor = 'pointer';
        posterImg.onclick = openInOverseerr;
        titleEl.style.cursor = 'pointer';
        titleEl.onclick = openInOverseerr;


        // Button Logic
        const btn = clone.querySelector('.request-btn');
        // trending-card no longer has .status-overlay
        
        btn.onclick = async () => {
            btn.textContent = "⏳";
            btn.disabled = true;
            try {
                const payload = {
                    mediaId: item.id,
                    mediaType: mediaType
                };

                if (mediaType === 'tv') {
                    const details = await Overseerr.getTv(url, key, item.id);
                    if (details && details.seasons) {
                        payload.seasons = details.seasons
                            .filter(s => s.seasonNumber !== 0)
                            .map(s => s.seasonNumber);
                    } else {
                         payload.seasons = [1]; 
                    }
                }

                await Overseerr.request(url, key, payload);
                
                btn.textContent = "✔ Requested";
                btn.style.background = "#4caf50";
                showNotification('Request sent successfully!', 'success');
                
                // Disable button permanently after success
                btn.disabled = true; 

            } catch (e) {
                console.error(e);
                btn.textContent = "❌ Failed";
                btn.title = e.message;
                showNotification(`Request failed: ${e.message}`, 'error');
                btn.disabled = false;
                setTimeout(() => { btn.textContent = "Request"; }, 2000);
            }
        };

        container.appendChild(clone);
    });
}

export async function doSearch(url, key, query) {
    if (!query) {
        return;
    }
    const container = document.getElementById('overseerr-search-results');
    if (container) {
        container.replaceChildren();
        const loading = document.createElement('div');
        loading.className = 'loading';
        loading.textContent = 'Searching...';
        container.appendChild(loading);
    }
    
    try {
      const results = await Overseerr.search(url, key, query);
      renderOverseerrSearch(results, url, key);
    } catch (e) {
      console.error("Search failed in doSearch:", e);
      if (container) {
          container.replaceChildren();
          const err = document.createElement('div');
          err.className = 'error';
          err.textContent = `Search Error: ${e.message}`;
          container.appendChild(err);
      }
    }
}

async function loadRequests(url, key, filter) {
    const container = document.getElementById('overseerr-requests');
    // If trending, use a different cache/logic
    const cacheKey = `overseerr_hydrated_${filter}`;
    
    // 1. Try Cache (Hydrated Data)
    const cached = localStorage.getItem(cacheKey);
    if (cached) {
        try {
           const hydratedData = JSON.parse(cached);
           renderHydratedRequests(hydratedData, url, key);
        } catch(e) { console.error("Cache parse error", e); }
    } else {
        if (container) {
            container.textContent = '';
            const loadingDiv = document.createElement('div');
            loadingDiv.className = 'loading';
            loadingDiv.textContent = `Loading ${filter} requests...`;
            container.appendChild(loadingDiv);
        }
    }
    
    try {
       // 2. Fetch Fresh Raw Data
       const rawData = await Overseerr.getRequests(url, key, filter);
       const requests = rawData.results || [];

       // 3. Hydrate Data (Fetch Details)
       const hydratedRequests = await hydrateRequests(requests, url, key);

       // 4. Save Cache & Render
       localStorage.setItem(cacheKey, JSON.stringify(hydratedRequests));
       renderHydratedRequests(hydratedRequests, url, key);

   } catch (e) {
       console.error(e);
        if (!cached && container) {
            container.replaceChildren();
            const err = document.createElement('div');
            err.className = 'error-banner';
            err.textContent = `Failed to load requests: ${e.message}`;
            container.appendChild(err);
        }
   }
}



function renderOverseerrSearch(results, url, key) {
    const container = document.getElementById('overseerr-search-results');
    if (!container) return;
    container.replaceChildren();
    
    if (results.length === 0) {
        const card = document.createElement('div');
        card.className = "card";
        const header = document.createElement('div');
        header.className = "card-header";
        header.textContent = "No results found";
        card.appendChild(header);
        container.appendChild(card);
        return;
    }

    const tmpl = document.getElementById('overseerr-search-card');

    results.filter(item => item.mediaType === 'movie' || item.mediaType === 'tv').forEach(item => {
        const clone = tmpl.content.cloneNode(true);
        
        // Image
        const posterImg = clone.querySelector('.poster-img');
        if (item.posterPath) {
           const posterUrl = `https://image.tmdb.org/t/p/w200${item.posterPath}`;
           posterImg.src = posterUrl;
        } else {
           // Fallback if no path initially
           posterImg.src = 'icons/icon48.png';
        }
        // Error Handler
        posterImg.addEventListener('error', () => {
            posterImg.src = 'icons/icon48.png';
        });

        if (item.backdropPath) {
             const backdropUrl = `https://image.tmdb.org/t/p/w500${item.backdropPath}`;
             clone.querySelector('.overseerr-backdrop').style.backgroundImage = `url('${backdropUrl}')`;
        }

        // Title
        const title = item.title || item.name || 'Unknown';
        const year = item.releaseDate ? item.releaseDate.split('-')[0] : (item.firstAirDate ? item.firstAirDate.split('-')[0] : '');
        
        clone.querySelector('.media-title').textContent = title;
        clone.querySelector('.media-year').textContent = year;
        clone.querySelector('.media-type').textContent = item.mediaType === 'movie' ? 'Movie' : 'TV';

        // Status / Button
        const btn = clone.querySelector('.request-btn');
        const statusDiv = clone.querySelector('.search-status-container');
        
        let statusText = "";
        let canRequest = true;

        // Clear statusDiv safe
        statusDiv.textContent = ''; 

        if (item.mediaInfo) {
            if (item.mediaInfo.status === 5) {
                statusText = "Available";
                // Create span safely
                const span = document.createElement('span');
                span.className = 'request-status status-text-available';
                span.textContent = statusText;
                statusDiv.appendChild(span);

                canRequest = false;
            } else if (item.mediaInfo.status === 4) {
                statusText = "Partially Available";
                const span = document.createElement('span');
                span.className = 'request-status status-text-partially';
                span.textContent = statusText;
                statusDiv.appendChild(span);
                
                // Treat partial as "owned" for simple UI to avoid confusion
                canRequest = false;
            } else if (item.mediaInfo.status === 2 || item.mediaInfo.status === 3) {
                 statusText = "Requested";
                 const span = document.createElement('span');
                 span.className = 'request-status status-text-pending'; // Reusing pending style for requested
                 span.textContent = statusText;
                 statusDiv.appendChild(span);
                 
                 canRequest = false;
            }
        }
        
        if (!canRequest) {
            btn.style.display = 'none';
        } else {
            btn.onclick = async () => {
                btn.textContent = "⏳";
                btn.disabled = true;
                try {
                    await Overseerr.request(url, key, {
                        mediaId: item.id,
                        mediaType: item.mediaType
                    });
                    btn.textContent = "✔";
                    btn.title = "Requested";
                    showNotification('Requested successfully!', 'success');
                } catch (e) {
                    console.error(e);
                    btn.textContent = "❌";
                    btn.title = "Failed: " + e.message;
                    showNotification("Failed to request: " + e.message, 'error');
                }
            };
        }

        container.appendChild(clone);
    });
}

async function hydrateRequests(requests, url, key) {
    if (!requests || requests.length === 0) return [];
    
    // PERFORMANCE: Batch API calls instead of sequential per-request calls
    // 1. Collect IDs by type
    const movieRequests = [];
    const tvRequests = [];
    
    requests.forEach((req, index) => {
        if (req.type === 'movie' && req.media?.tmdbId) {
            movieRequests.push({ index, id: req.media.tmdbId });
        } else if (req.type === 'tv' && req.media?.tmdbId) {
            tvRequests.push({ index, id: req.media.tmdbId });
        }
    });
    
    // 2. Fetch all in parallel (movies and TVs simultaneously)
    // Use allSettled to prevent one failure from breaking the entire list
    const [movieResults, tvResults] = await Promise.all([
        Promise.allSettled(movieRequests.map(m => Overseerr.getMovie(url, key, m.id))),
        Promise.allSettled(tvRequests.map(t => Overseerr.getTv(url, key, t.id)))
    ]);
    
    // 3. Build lookup maps for O(1) access
    const movieMap = new Map();
    const tvMap = new Map();
    movieRequests.forEach((m, i) => {
        if (movieResults[i].status === 'fulfilled') {
            movieMap.set(m.id, movieResults[i].value);
        }
    });
    tvRequests.forEach((t, i) => {
        if (tvResults[i].status === 'fulfilled') {
            tvMap.set(t.id, tvResults[i].value);
        }
    });
    
    // 4. Enrich requests
    return requests.map(req => {
        const enhancedReq = { ...req };
        const tmdbId = req.media?.tmdbId;
        let details = null;
        
        if (req.type === 'movie') {
            details = movieMap.get(tmdbId);
        } else if (req.type === 'tv') {
            details = tvMap.get(tmdbId);
        }
        
        enhancedReq.details = {
            title: details?.title || details?.name || "Unknown",
            posterPath: details?.posterPath || "",
            backdropPath: details?.backdropPath || "",
            year: (details?.releaseDate || details?.firstAirDate || "").split('-')[0]
        };
        
        return enhancedReq;
    });
}

function renderHydratedRequests(requests, url, key) {
    const container = document.getElementById('overseerr-requests');
    if (!container) return;
    container.replaceChildren();

    if (requests.length === 0) {
        const card = document.createElement('div');
        card.className = "card";
        const header = document.createElement('div');
        header.className = "card-header";
        header.textContent = "No pending requests";
        card.appendChild(header);
        container.appendChild(card);
        return;
    }

    const tmpl = document.getElementById('overseerr-card');

    requests.forEach((req) => {
        const clone = tmpl.content.cloneNode(true);
        const media = req.media;
        const details = req.details || {}; 
        
        const title = details.title || "Loading...";
        const posterPath = details.posterPath || "";
        const backdropPath = details.backdropPath || "";
        
        const posterImg = clone.querySelector('.poster-img');
        if (posterPath) {
           const posterUrl = `https://image.tmdb.org/t/p/w200${posterPath}`;
           posterImg.src = posterUrl;

           if (backdropPath) {
               const backdropUrl = `https://image.tmdb.org/t/p/w500${backdropPath}`;
               clone.querySelector('.overseerr-backdrop').style.backgroundImage = `url('${backdropUrl}')`;
           }
        } else {
           posterImg.src = 'icons/icon48.png';
        }
        // Error Handler
        posterImg.addEventListener('error', () => {
            posterImg.src = 'icons/icon48.png';
        });

        clone.querySelector('.media-title').textContent = title;
        
        const requester = req.requestedBy ? (req.requestedBy.displayName || req.requestedBy.email) : 'Unknown';
        const dateStr = new Date(req.createdAt).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: 'numeric' });
        
        const titleEl = clone.querySelector('.media-title');
        titleEl.textContent = title;
        titleEl.classList.add('clickable-link');
        titleEl.addEventListener('click', (e) => {
            e.stopPropagation();
            let baseUrl = url;
            if (!baseUrl.startsWith('http')) { baseUrl = 'http://' + baseUrl; }
            if (baseUrl.endsWith('/')) { baseUrl = baseUrl.slice(0, -1); }

            let targetUrl = '';
            // Using media info or request type
            let tmdbId = media ? media.tmdbId : null;
            
            // Fallback for safety
            if (!tmdbId && req.mediaType === 'movie') tmdbId = req.mediaId; // Might depend on response structure?
            
            if (req.type === 'movie') {
                targetUrl = `${baseUrl}/movie/${tmdbId}`;
            } else if (req.type === 'tv') {
                targetUrl = `${baseUrl}/tv/${tmdbId}`;
            }

            if (targetUrl) {
                chrome.tabs.create({ url: targetUrl });
            }
        });
        clone.querySelector('.requester-name').textContent = requester;
        clone.querySelector('.request-date').textContent = dateStr;

        // Request Status / Type
        let statusText = "Pending Approval";
        let statusClass = "status-text-pending"; // Default

        // Request Status: 1=Pending, 2=Approved, 3=Declined
        if (req.status === 1) {
            statusText = "Pending Approval";
            statusClass = "status-text-pending";
        } else if (req.status === 2) {
            statusText = "Approved";
            statusClass = "status-text-approved";

            // Check Media Status if Approved
            if (media) {
                if (media.status === 3) {
                    statusText = "Processing";
                    statusClass = "status-text-processing";
                } else if (media.status === 4) {
                    statusText = "Partially Available";
                    statusClass = "status-text-partially";
                } else if (media.status === 5) {
                    statusText = "Available";
                    statusClass = "status-text-available";
                }
            }
        } else if (req.status === 3) {
            statusText = "Declined";
            statusClass = "status-text-declined";
        }
        
        const statusEl = clone.querySelector('.request-status');
        statusEl.textContent = statusText;
        // Apply class instead of inline styles
        statusEl.className = `request-status ${statusClass}`;
        // Clear old inline styles from previous logic if any (clone is fresh but good practice)
        statusEl.style = ""; 

        // Actions - Only show if Pending (1)
        const actionsDiv = clone.querySelector('.overseerr-actions');
        if (req.status !== 1) {
            actionsDiv.style.display = 'none';
        } else {
            const approveBtn = clone.querySelector('.approve-btn');
            const declineBtn = clone.querySelector('.decline-btn');

            if (approveBtn) {
               approveBtn.onclick = async () => {
                  approveBtn.disabled = true;
                  const success = await Overseerr.approveRequest(url, key, req.id);
                  if (success) {
                      loadRequests(url, key, document.getElementById('overseerr-filter')?.value || 'pending');
                      showNotification(`Request "${title}" approved`, 'success');
                  }
               };
            }

            if (declineBtn) {
                declineBtn.onclick = async () => {
                    declineBtn.disabled = true;
                    // Custom Modal
                    const confirmed = await showConfirmModal(
                        'Decline Request',
                        `Decline request for ${title}?`,
                        'Decline',
                        '#f44336'
                    );
                    
                    if (confirmed) {
                        const success = await Overseerr.declineRequest(url, key, req.id);
                        if (success) {
                             loadRequests(url, key, document.getElementById('overseerr-filter')?.value || 'pending');
                             showNotification(`Request "${title}" declined`, '#f44336'); // Red for declined
                        }
                    } else {
                        declineBtn.disabled = false;
                    }
                };
            }
        }

        container.appendChild(clone);
    });
}
